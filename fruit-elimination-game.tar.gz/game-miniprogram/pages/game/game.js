
const FRUITS = ['🍎', '🍊', '🍋', '🍉', '🍇', '🍓', '🍑', '🍍']
const GRID_SIZE = 8
const INIT_STEPS = 30

Page({
  data: {
    grid: [],
    score: 0,
    steps: INIT_STEPS,
    selected: []
  },

  onLoad() {
    this.initGame()
  },

  initGame() {
    const grid = Array(GRID_SIZE * GRID_SIZE).fill().map(() => 
      FRUITS[Math.floor(Math.random() * FRUITS.length)]
    )
    this.setData({ 
      grid, 
      score: 0, 
      steps: INIT_STEPS,
      selected: []
    })
  },

  handleTap(e) {
    if (this.data.steps <= 0) return
    
    const index = e.currentTarget.dataset.index
    const fruit = this.data.grid[index]
    
    // 寻找相邻的相同水果
    const connected = this.findConnected(index, fruit)
    
    if (connected.length >= 2) {
      // 消除水果
      const newGrid = [...this.data.grid]
      connected.forEach(i => newGrid[i] = '')
      
      // 下落填补空白
      this.dropFruits(newGrid)
      
      // 计算分数
      const addScore = connected.length * 10 + (connected.length - 2) * 5
      const newScore = this.data.score + addScore
      
      // 减少步数
      const newSteps = this.data.steps - 1
      
      this.setData({
        grid: newGrid,
        score: newScore,
        steps: newSteps
      })
      
      // 检查游戏是否结束
      if (newSteps <= 0) {
        this.endGame()
      }
    }
  },

  findConnected(startIndex, targetFruit) {
    const visited = new Set()
    const queue = [startIndex]
    const result = []
    
    while (queue.length > 0) {
      const index = queue.shift()
      if (visited.has(index)) continue
      if (this.data.grid[index] !== targetFruit) continue
      
      visited.add(index)
      result.push(index)
      
      // 检查上下左右
      const row = Math.floor(index / GRID_SIZE)
      const col = index % GRID_SIZE
      
      const directions = [
        [-1, 0], [1, 0], [0, -1], [0, 1]
      ]
      
      for (const [dr, dc] of directions) {
        const newRow = row + dr
        const newCol = col + dc
        if (newRow >= 0 && newRow < GRID_SIZE && newCol >=0 && newCol < GRID_SIZE) {
          const newIndex = newRow * GRID_SIZE + newCol
          if (!visited.has(newIndex)) {
            queue.push(newIndex)
          }
        }
      }
    }
    
    return result
  },

  dropFruits(grid) {
    for (let col = 0; col < GRID_SIZE; col++) {
      // 收集当前列的非空水果
      const column = []
      for (let row = 0; row < GRID_SIZE; row++) {
        const index = row * GRID_SIZE + col
        if (grid[index] !== '') {
          column.push(grid[index])
        }
      }
      
      // 补充空白
      while (column.length < GRID_SIZE) {
        column.unshift(FRUITS[Math.floor(Math.random() * FRUITS.length)])
      }
      
      // 更新列
      for (let row = 0; row < GRID_SIZE; row++) {
        const index = row * GRID_SIZE + col
        grid[index] = column[row]
      }
    }
  },

  useHint() {
    // 简单提示功能：找到第一个可消除的组
    for (let i = 0; i < this.data.grid.length; i++) {
      if (this.data.grid[i] === '') continue
      const connected = this.findConnected(i, this.data.grid[i])
      if (connected.length >= 2) {
        wx.showToast({
          title: '有可消除的水果',
          icon: 'none'
        })
        return
      }
    }
    wx.showToast({
      title: '没有可消除的水果',
      icon: 'none'
    })
  },

  useBomb() {
    // 炸弹功能：随机消除3x3区域
    const center = Math.floor(Math.random() * this.data.grid.length)
    const row = Math.floor(center / GRID_SIZE)
    const col = center % GRID_SIZE
    
    const toRemove = []
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        const newRow = row + dr
        const newCol = col + dc
        if (newRow >=0 && newRow < GRID_SIZE && newCol >=0 && newCol < GRID_SIZE) {
          toRemove.push(newRow * GRID_SIZE + newCol)
        }
      }
    }
    
    const newGrid = [...this.data.grid]
    toRemove.forEach(i => newGrid[i] = '')
    this.dropFruits(newGrid)
    
    this.setData({
      grid: newGrid,
      score: this.data.score + toRemove.length * 5,
      steps: this.data.steps - 1
    })
  },

  endGame() {
    const highestScore = wx.getStorageSync('highestScore') || 0
    if (this.data.score > highestScore) {
      wx.setStorageSync('highestScore', this.data.score)
    }
    
    wx.navigateTo({
      url: '/pages/result/result?score=' + this.data.score
    })
  }
})
