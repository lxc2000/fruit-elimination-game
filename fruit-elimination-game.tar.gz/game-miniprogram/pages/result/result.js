
Page({
  data: {
    score: 0,
    highestScore: 0,
    isNewRecord: false
  },

  onLoad(options) {
    const score = parseInt(options.score) || 0
    const highestScore = wx.getStorageSync('highestScore') || 0
    const isNewRecord = score > highestScore
    
    this.setData({
      score,
      highestScore: Math.max(score, highestScore),
      isNewRecord
    })
  },

  restart() {
    wx.redirectTo({
      url: '/pages/game/game'
    })
  },

  backToHome() {
    wx.redirectTo({
      url: '/pages/index/index'
    })
  }
})
