
Page({
  data: {
    highestScore: 0
  },
  onLoad() {
    const highestScore = wx.getStorageSync('highestScore') || 0
    this.setData({ highestScore })
  },
  startGame() {
    wx.navigateTo({
      url: '/pages/game/game'
    })
  }
})
